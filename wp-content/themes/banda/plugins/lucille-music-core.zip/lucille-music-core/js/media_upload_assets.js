'use strict';
if (typeof LUCILLE_SWP_scriptParams !== "undefined") {
	var post_id = LUCILLE_SWP_scriptParams.post_id;
	var shortform = LUCILLE_SWP_scriptParams.short_form;
}